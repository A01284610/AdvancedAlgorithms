/*
 * Fecha: 22 Mayo 2023
 * Autores:
 *   Matricula: A01652327
 *   Nombre: Diego Esparza Hurtado
 *
 *   Matricula: A01284610
 *   Nombre: Alejandro Lizarraga Vizcarra
 * 
 *   Matricula: A00833547
 *   Nombre: Samuel Acosta Ugarte
 *
 * Actividad Integradora 2 - Alta demanda para los Proveedores de Servicios de Internet (ISP)
 *    Parte 1:
 *          Se busca si el contenido de alguno de tres archivos 'mcodeX.txt' se encuentra en alguno de los dos archivos de transmision 'transmissionY.txt'.
 *          En caso de estarlo, se imprime un 'true' y la posicion donde inician. En caso de no hacerlo, se imprime un false.
 *    Parte 2:
 *          Se busca el palindromo mas largo contenido en cada uno de los archivos 'transmissionY.txt'.
 *          Se imprime la posicion inicial y final del palindromo mas largo de cada archivo iniciando en '1'.
 *    Parte 3:
 *          Se busca la subcadena comun mas larga (LCS - Longest Common Substring) entre los dos archivos 'transmissionY.txt'.
 *          Se imprime la posicion inicial y final de la subcadena comun mas larga (LCS - Longest Common Substring) con respecto al archivo 'transmission1.txt' iniciando en '1'.
 *
 * Para compilar: 
 * g++ -o a.out main.cpp
 *
 * Para ejecutar:
 * ./a.out < test01.txt
*/

#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using std::cin;
using std::cout;
using std::endl;
using std::vector;
using std::string;
using std::pair;
using std::istream;

struct Datos{

    

};