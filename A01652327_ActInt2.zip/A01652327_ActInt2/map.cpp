/*
 * Fecha: 22 Mayo 2023
 * Autores:
 *   Matricula: A01652327
 *   Nombre: Diego Esparza Hurtado
 *
 *   Matricula: A01284610
 *   Nombre: Alejandro Lizarraga Vizcarra
 * 
 *   Matricula: A00833547
 *   Nombre: Samuel Acosta Ugarte
 *
 * Actividad Integradora 2 - Alta demanda para los Proveedores de Servicios de Internet (ISP)
 * 
 *    Parte 1: CAMBIAR TODO
 *          Se busca si el contenido de alguno de tres archivos 'mcodeX.txt' se encuentra en alguno de los dos archivos de transmision 'transmissionY.txt'.
 *          En caso de estarlo, se imprime un 'true' y la posicion donde inician. En caso de no hacerlo, se imprime un false.
 *    Parte 2:
 *          Se busca el palindromo mas largo contenido en cada uno de los archivos 'transmissionY.txt'.
 *          Se imprime la posicion inicial y final del palindromo mas largo de cada archivo iniciando en '1'.
 *    Parte 3:
 *          Se busca la subcadena comun mas larga (LCS - Longest Common Substring) entre los dos archivos 'transmissionY.txt'.
 *          Se imprime la posicion inicial y final de la subcadena comun mas larga (LCS - Longest Common Substring) con respecto al archivo 'transmission1.txt' iniciando en '1'.
 *    Parte 4:
 *
 * 
 * Para compilar: 
 * g++ -o a.out main.cpp
 *
 * Para ejecutar:
 * ./a.out
*/

#include <iostream>
#include <queue>
#include <cmath> //checar necesidad



using std::cin;
using std::cout;
using std::endl;
using std::min;
using std::priority_queue;



// Viajero:
// Pag: 293
// O(2^n)
struct Nodo{
    int iNivel;
    int iCostoAcum;
    int iCostoPos;
    int iVisitedAnt;
    int iVisitedNow;
    bool bVisited[21];
    bool operator < (const Nodo &aux) const{
        return iCostoPos >= aux.iCostoPos;
    }
};

int iN;
int iMatDist[21][21];
int iMinCost = 1000000;
priority_queue<Nodo> qNodos;

void calcularValorAcum(Nodo &nodoActual){
    nodoActual.iCostoAcum += iMatDist[nodoActual.iVisitedAnt][nodoActual.iVisitedNow];
}

void calcularValorPosible(Nodo &nodoActual){
    nodoActual.iCostoPos = nodoActual.iCostoAcum;
    int iNivel = nodoActual.iNivel, iNodoAct = nodoActual.iVisitedNow, iTemp = 1000000;
    for (int iI = 1, iK = iN-iNivel; iI <= iN && iK >= 0; iI++){
        if (!nodoActual.bVisited[iI] || iI == iNodoAct){
            if (!nodoActual.bVisited[iI]){
                for (int iJ = 1; iJ <= iN; iJ++){
                    if (iI != iJ && (!nodoActual.bVisited[iJ] || iJ == 1)){
                        iTemp = min(iTemp, iMatDist[iI][iJ]);
                    }
                }
            }
            else if (iI == iNodoAct){
                for (int iJ = 1; iJ <= iN; iJ++){
                    if (!nodoActual.bVisited[iJ]){
                        iTemp = min(iTemp, iMatDist[iI][iJ]);
                    }
                }
            }
            nodoActual.iCostoPos += iTemp;
            iTemp = DISTMIN; //Preguntar ; Cambiar por int max?
            iK--;
        }
    }
}

void calcularValorFinal(Nodo &nodoActual){
    int iLastNode = -1;
    calcularValorAcum(nodoActual);
    for (int iI = 1; iI <= iN && iLastNode == -1; iI++){
        if (!nodoActual.bVisited[iI]){
            iLastNode = iI;
        }
    }
    nodoActual.iCostoAcum += iMatDist[nodoActual.iVisitedNow][iLastNode];
    nodoActual.iCostoAcum += iMatDist[iLastNode][1];
}

void branchAndBound(Nodo raiz){
    Nodo nodoAux, nodoHijo;
    qNodos.push(raiz);
    while (!qNodos.empty()){
        nodoAux = qNodos.top();
        qNodos.pop();
        if (nodoAux.iCostoPos <= iMinCost){
            for (int iI = 1; iI <= iN; iI++){
                if (!nodoAux.bVisited[iI]){
                    nodoHijo.iNivel = nodoAux.iNivel + 1;
                    memcpy(nodoHijo.bVisited, nodoAux.bVisited, (iN+1) * sizeof(bool));
                    nodoHijo.bVisited[iI] = true;
                    nodoHijo.iVisitedAnt = nodoAux.iVisitedNow;
                    nodoHijo.iVisitedNow = iI;
                    nodoHijo.iCostoAcum = nodoAux.iCostoAcum;
                    if (nodoHijo.iNivel == iN-2){
                        calcularValorFinal(nodoHijo);
                        iMinCost = min(iMinCost, nodoHijo.iCostoAcum);
                    }
                    else {
                        calcularValorAcum(nodoHijo);
                        calcularValorPosible(nodoHijo);
                        qNodos.push(nodoHijo);
                    }
                }
            }
        }
    }
}





int main(){

    // Initialize the distance matrix and the number of cities
    iN = 4;
    iMatDist[1][2] = iMatDist[2][1] = 10;
    iMatDist[1][3] = iMatDist[3][1] = 15;
    iMatDist[1][4] = iMatDist[4][1] = 20;
    iMatDist[2][3] = iMatDist[3][2] = 35;
    iMatDist[2][4] = iMatDist[4][2] = 25;
    iMatDist[3][4] = iMatDist[4][3] = 30;

    // Create the root node
    Nodo raiz;
    raiz.iNivel = 1;
    raiz.iCostoAcum = 0;
    raiz.iCostoPos = 0;
    raiz.iVisitedAnt = 1;
    raiz.iVisitedNow = 1;
    memset(raiz.bVisited, false, sizeof(raiz.bVisited));
    raiz.bVisited[1] = true;

    // Solve the TSP using Branch and Bound
    branchAndBound(raiz);

    // Print the minimum cost of a Hamiltonian cycle
    std::cout << "Minimum cost of a Hamiltonian cycle: " << iMinCost << std::endl;

    return 0;
}